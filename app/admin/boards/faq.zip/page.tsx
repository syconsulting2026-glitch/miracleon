"use client";

import Header from "@/components/admin/Header";
import Sidebar from "@/components/admin/Siderbar";
import Link from "next/link";
import { useMemo, useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

type FaqItem = {
  id: number;
  category: string;
  question: string;
  answer: string;
  author: string;
  createdAt: string;
  views: number;
  isPinned?: boolean;
  isVisible: boolean;
};

const initialFaqItems: FaqItem[] = [
  {
    id: 3,
    category: "수업안내",
    question: "AI 활용 수업은 누구나 신청할 수 있나요?",
    answer:
      "네, 초보자도 참여 가능합니다.\n연령과 배경에 맞는 기초 중심 프로그램으로 진행됩니다.",
    author: "관리자",
    createdAt: "2026-03-13",
    views: 21,
    isPinned: true,
    isVisible: true,
  },
  {
    id: 2,
    category: "활동안내",
    question: "플로깅 활동은 준비물이 필요한가요?",
    answer:
      "기본적인 준비물은 안내드리며, 편한 복장과 운동화 정도를 준비하시면 됩니다.",
    author: "관리자",
    createdAt: "2026-03-11",
    views: 14,
    isVisible: true,
  },
  {
    id: 1,
    category: "기부안내",
    question: "재능기부 참여는 어떻게 하나요?",
    answer:
      "문의 페이지 또는 운영진 연락처를 통해 참여 의사를 전달해주시면 안내드립니다.",
    author: "관리자",
    createdAt: "2026-03-09",
    views: 11,
    isVisible: false,
  },
];

const AdminFaqPage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [faqItems, setFaqItems] = useState<FaqItem[]>(initialFaqItems);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("전체");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [openIds, setOpenIds] = useState<number[]>([]);

  const toggleSidebar = () => setSidebarOpen((prev) => !prev);

  const filteredItems = useMemo(() => {
    let items = [...faqItems];

    if (categoryFilter !== "전체") {
      items = items.filter((item) => item.category === categoryFilter);
    }

    if (searchKeyword.trim()) {
      items = items.filter(
        (item) =>
          item.question.toLowerCase().includes(searchKeyword.toLowerCase()) ||
          item.answer.toLowerCase().includes(searchKeyword.toLowerCase())
      );
    }

    return items.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.id - a.id;
    });
  }, [faqItems, searchKeyword, categoryFilter]);

  const allVisibleIds = filteredItems.map((item) => item.id);
  const isAllSelected =
    allVisibleIds.length > 0 &&
    allVisibleIds.every((id) => selectedIds.includes(id));

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds((prev) => prev.filter((id) => !allVisibleIds.includes(id)));
    } else {
      setSelectedIds((prev) => Array.from(new Set([...prev, ...allVisibleIds])));
    }
  };

  const toggleSelectOne = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleAccordion = (id: number) => {
    setOpenIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) {
      alert("삭제할 FAQ를 선택해주세요.");
      return;
    }

    const ok = window.confirm(
      `선택한 ${selectedIds.length}개의 FAQ를 삭제하시겠습니까?`
    );

    if (!ok) return;

    setFaqItems((prev) => prev.filter((item) => !selectedIds.includes(item.id)));
    setSelectedIds([]);
    setOpenIds((prev) => prev.filter((id) => !selectedIds.includes(id)));
  };

  const handleDeleteOne = (id: number) => {
    const ok = window.confirm("이 FAQ를 삭제하시겠습니까?");
    if (!ok) return;

    setFaqItems((prev) => prev.filter((item) => item.id !== id));
    setSelectedIds((prev) => prev.filter((item) => item !== id));
    setOpenIds((prev) => prev.filter((item) => item !== id));
  };

  return (
    <div className="min-h-screen w-full bg-gray-50 text-gray-900">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <Sidebar sidebarOpen={sidebarOpen} />

      <div className="lg:pl-72">
        <Header sidebarOpen={sidebarOpen} onToggleSidebar={toggleSidebar} />

        <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 lg:px-8">
          <section className="space-y-6">
            <div className="flex flex-col gap-4 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">게시판 관리</p>
                <h1 className="mt-1 text-2xl font-bold tracking-tight text-gray-900">
                  FAQ 관리
                </h1>
                <p className="mt-1 text-sm text-gray-500">
                  FAQ를 아코디언 방식으로 확인하고 수정, 삭제할 수 있습니다.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleDeleteSelected}
                  className="inline-flex h-11 items-center justify-center rounded-xl border border-red-200 bg-red-50 px-4 text-sm font-semibold text-red-600 transition hover:bg-red-100"
                >
                  선택 삭제
                </button>

                <Link
                  href="/admin/boards/faq/write"
                  className="inline-flex h-11 items-center justify-center rounded-xl bg-gray-900 px-4 text-sm font-semibold text-white transition hover:bg-gray-700"
                >
                  글쓰기
                </Link>
              </div>
            </div>

            <div className="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_180px_120px]">
                <input
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="질문 또는 답변 검색"
                  className="h-11 rounded-xl border border-gray-200 px-4 text-sm outline-none transition focus:border-gray-400"
                />

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="h-11 rounded-xl border border-gray-200 px-4 text-sm outline-none transition focus:border-gray-400"
                >
                  <option>전체</option>
                  <option>수업안내</option>
                  <option>활동안내</option>
                  <option>기부안내</option>
                  <option>기타</option>
                </select>

                <button
                  type="button"
                  className="h-11 rounded-xl bg-gray-100 text-sm font-semibold text-gray-700 transition hover:bg-gray-200"
                >
                  검색
                </button>
              </div>
            </div>

            <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
              <div className="hidden grid-cols-[60px_80px_120px_1fr_100px_100px_140px_90px_80px] bg-gray-100 px-6 py-4 text-sm font-semibold text-gray-700 md:grid">
                <div className="flex items-center justify-center">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={toggleSelectAll}
                    className="h-4 w-4"
                  />
                </div>
                <div>번호</div>
                <div>카테고리</div>
                <div>질문</div>
                <div>노출</div>
                <div>고정</div>
                <div>작성일</div>
                <div>조회수</div>
                <div>보기</div>
              </div>

              <div className="divide-y divide-gray-200">
                {filteredItems.length > 0 ? (
                  filteredItems.map((item) => {
                    const isOpen = openIds.includes(item.id);

                    return (
                      <div key={item.id}>
                        <div className="px-4 py-4 transition hover:bg-gray-50 md:px-6">
                          <div className="grid grid-cols-1 gap-3 md:grid-cols-[60px_80px_120px_1fr_100px_100px_140px_90px_80px] md:items-center">
                            <div className="flex items-center justify-start md:justify-center">
                              <input
                                type="checkbox"
                                checked={selectedIds.includes(item.id)}
                                onChange={() => toggleSelectOne(item.id)}
                                className="h-4 w-4"
                              />
                            </div>

                            <div className="text-sm font-semibold text-gray-600">
                              {item.id}
                            </div>

                            <div>
                              <span className="inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                                {item.category}
                              </span>
                            </div>

                            <button
                              type="button"
                              onClick={() => toggleAccordion(item.id)}
                              className="flex min-w-0 items-center gap-2 text-left"
                            >
                              <span className="truncate font-medium text-gray-900 hover:text-blue-600">
                                {item.question}
                              </span>
                            </button>

                            <div>
                              {item.isVisible ? (
                                <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                                  노출
                                </span>
                              ) : (
                                <span className="inline-flex rounded-full bg-gray-200 px-3 py-1 text-xs font-semibold text-gray-700">
                                  숨김
                                </span>
                              )}
                            </div>

                            <div>
                              {item.isPinned ? (
                                <span className="inline-flex rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-600">
                                  고정
                                </span>
                              ) : (
                                <span className="text-sm text-gray-400">-</span>
                              )}
                            </div>

                            <div className="text-sm text-gray-600">{item.createdAt}</div>
                            <div className="text-sm text-gray-600">{item.views}</div>

                            <button
                              type="button"
                              onClick={() => toggleAccordion(item.id)}
                              className="inline-flex items-center justify-center text-gray-500"
                            >
                              {isOpen ? (
                                <ChevronUp className="h-5 w-5" />
                              ) : (
                                <ChevronDown className="h-5 w-5" />
                              )}
                            </button>
                          </div>

                          <div className="mt-1 text-xs text-gray-500 md:hidden">
                            작성일 {item.createdAt} · 조회 {item.views}
                          </div>
                        </div>

                        {isOpen && (
                          <div className="border-t border-gray-100 bg-gray-50 px-4 py-5 md:px-6">
                            <div className="space-y-4 rounded-2xl border border-gray-200 bg-white p-5">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                                  {item.category}
                                </span>

                                {item.isPinned && (
                                  <span className="inline-flex rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-600">
                                    상단 고정
                                  </span>
                                )}

                                {item.isVisible ? (
                                  <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                                    노출중
                                  </span>
                                ) : (
                                  <span className="inline-flex rounded-full bg-gray-200 px-3 py-1 text-xs font-semibold text-gray-700">
                                    숨김
                                  </span>
                                )}
                              </div>

                              <div className="rounded-2xl border border-gray-200 bg-gray-50 p-4">
                                <p className="mb-2 text-sm font-semibold text-gray-500">
                                  질문
                                </p>
                                <div className="whitespace-pre-wrap text-[15px] leading-7 text-gray-900">
                                  {item.question}
                                </div>
                              </div>

                              <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4">
                                <p className="mb-2 text-sm font-semibold text-blue-700">
                                  답변
                                </p>
                                <div className="whitespace-pre-wrap text-[15px] leading-7 text-gray-700">
                                  {item.answer}
                                </div>
                              </div>

                              <div className="flex flex-wrap justify-end gap-3 pt-2">
                                <Link
                                  href={`/admin/boards/faq/write?id=${item.id}`}
                                  className="inline-flex h-10 items-center justify-center rounded-xl border border-gray-300 bg-white px-4 text-sm font-semibold text-gray-700 transition hover:bg-gray-100"
                                >
                                  수정하기
                                </Link>

                                <button
                                  type="button"
                                  onClick={() => handleDeleteOne(item.id)}
                                  className="inline-flex h-10 items-center justify-center rounded-xl border border-red-200 bg-red-50 px-4 text-sm font-semibold text-red-600 transition hover:bg-red-100"
                                >
                                  삭제하기
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                ) : (
                  <div className="px-6 py-16 text-center text-sm text-gray-500">
                    검색된 FAQ가 없습니다.
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <p className="text-sm text-gray-500">
                선택된 항목: <span className="font-semibold">{selectedIds.length}</span>개
              </p>

              <div className="flex items-center justify-center gap-2">
                <button className="flex h-10 min-w-10 items-center justify-center rounded-lg border border-gray-200 bg-white px-3 text-sm text-gray-600">
                  이전
                </button>
                <button className="flex h-10 min-w-10 items-center justify-center rounded-lg bg-gray-900 px-3 text-sm font-semibold text-white">
                  1
                </button>
                <button className="flex h-10 min-w-10 items-center justify-center rounded-lg border border-gray-200 bg-white px-3 text-sm text-gray-600">
                  다음
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}

export default AdminFaqPage;